(function($) {
	Drupal.behaviors.reviewerSelectFormAddReviewer = {
		attach : function(context, settings) {
            /* meta function to show/hide custom email box and fill it with proper values. */
		$('form-item').find('tabledrag-toggle-weight-wrapper').hide();
})(jQuery);
